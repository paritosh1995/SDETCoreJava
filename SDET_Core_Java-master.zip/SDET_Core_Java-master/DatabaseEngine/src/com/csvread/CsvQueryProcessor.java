package com.csvread;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import com.query.DataSet;
import com.query.DataTypeDefinitions;
import com.query.Filter;
import com.query.Header;
import com.query.QueryParameter;
import com.query.Row;
import com.query.RowDataTypeDefinitions;

public class CsvQueryProcessor implements QueryProcessingEngine{

	public DataSet getResultSet(QueryParameter queryParameter){
		FileReader fr;
		BufferedReader br = null;	
		String[] headers = null;
		String[] fields = null;
		
		//Reading the csv file - Header and First Row
			try {
				
				fr = new FileReader(queryParameter.getFileName());
				br = new BufferedReader(fr);
				headers = br.readLine().split(",");
				br.mark(1);
				fields = br.readLine().split(",",headers.length);
				
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			//Storing the Headers
			Header headerMap = new Header();
			for(int i=0;i<headers.length;i++){
				headerMap.put(headers[i].trim(), i);
			}

			//Storing the dataType of each column
			RowDataTypeDefinitions rowDataType = new RowDataTypeDefinitions();
			for(int i=0;i<fields.length;i++){
				rowDataType.put(i,DataTypeDefinitions.getDataType(fields[i]));
			}
			
			//Reseting the Line to First row (First field data)
			try {
				br.reset();
			} catch (IOException e) {
				e.printStackTrace();
			}
	
			DataSet dataSet = new DataSet();
			long setRowIndex = 1;
			Filter filter = new Filter();
			String line;
			try {
				while((line = br.readLine()) != null){
					String[] rowFields = line.split(",",headers.length);
					boolean result = false;
					ArrayList<Boolean> bools = new ArrayList<Boolean>();
					
					if(queryParameter.getRestrictions() == null){
						result = true;
					} else{
						for(int i=0;i<queryParameter.getRestrictions().size();i++) {
							int index = headerMap.get(queryParameter.getRestrictions().get(i).getName());
							bools.add(filter.evaluateExpression(queryParameter.getRestrictions().get(i), rowFields[index].trim(), rowDataType.get(index)));						
						}
						result = solveOperators(bools,queryParameter.getLogicalOpt());
					}
					
					if(result){
						Row rowMap = new Row();
						for(int i=0;i<queryParameter.getFields().size();i++){
							if((queryParameter.getFields().get(i)).equals("*")){
								for(int j=0;j<headers.length;j++){
									rowMap.put(headers[j].trim(), rowFields[j].trim());
								}
							} else {
								rowMap.put(queryParameter.getFields().get(i), rowFields[headerMap.get(queryParameter.getFields().get(i))]);
							}
						}
						dataSet.put(setRowIndex++, rowMap);
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			return dataSet;
	
	}
	
	
	private Boolean solveOperators(ArrayList<Boolean> bools, String operators){
		if(bools.size() == 1){
			return bools.get(0);
		} else if(bools.size() == 2){
			if(operators.matches("and")){
				return bools.get(0) & bools.get(1);
			}else{
				return bools.get(0) | bools.get(1);
			}
		}else{
			System.out.println("Query takes maximun of 2 conditions");
			return false;
		}
	}
	
}

