package com.csvread;

import com.query.DataSet;
import com.query.QueryParameter;

public interface QueryProcessingEngine {
	
	public DataSet getResultSet(QueryParameter queryParameter);
}
