package com.dbengine;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


import com.query.Query;
import com.writer.JsonWriter;

public class DbEngineDriver {

	public static void main(String[] args) {
		
		System.out.println("Enter the Query : ");
		String qry = null ;
		
		//Reading Query
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			qry = reader.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Query query = new Query();
		
		JsonWriter jsonwriter = new JsonWriter();
		jsonwriter.writeToJson(query.executeQuery(qry));

		System.out.println("Output in Json");
	}

}
