package com.query;

public class AggregateFunction {
	String aggName ;
	String aggField ;
	
	public AggregateFunction (String aggName,String aggField) {
		this.aggName = aggName;
		this.aggField = aggField;
	}
	
	public String getAggName() {
		return aggName;
	}
	
	public void setAggName(String aggName) {
		this.aggName = aggName;
	}
	
	public String getAggField() {
		return aggField;
	}
	
	public void setAggField(String aggField) {
		this.aggField = aggField;
	}
	
	public String toString(){
		return "AggregateFunction [ AggName = "+aggName+", AggField = "+aggField+" ]";
	}
}
