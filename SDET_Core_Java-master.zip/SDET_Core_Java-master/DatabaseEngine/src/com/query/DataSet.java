package com.query;

import java.util.LinkedHashMap;

public class DataSet extends LinkedHashMap<Long, Row>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
 