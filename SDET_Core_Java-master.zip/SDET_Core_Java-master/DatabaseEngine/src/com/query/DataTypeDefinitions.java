package com.query;

public class DataTypeDefinitions {
	
	public static String getDataType(String type){
		
		if(type.matches("[0-9]+")){
			return "java.lang.Integer";
		} else if(type.matches("(0[1-9]|[12][0-9]|3[01])[-](0[1-9]|1[012])[-]\\d{4}")){
			return "java.lang.Date";
		} else if(type.isEmpty()){
			return "java.lang.Object";
		} else {
			return "java.lang.String";
		}
	}
	
}
