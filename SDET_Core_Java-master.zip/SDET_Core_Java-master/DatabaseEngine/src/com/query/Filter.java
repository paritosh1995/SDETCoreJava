package com.query;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Filter {
	
	public boolean evaluateExpression(Restriction restriction, String fieldValue, String dataType ){
		if(restriction.getCondition().equals("="))
			return isEqual(fieldValue, restriction.getValue(), dataType);
		else if(restriction.getCondition().equals("!="))
			return isNotEqual(fieldValue, restriction.getValue(), dataType);
		else if(restriction.getCondition().equals(">"))
			return isGreaterThan(fieldValue, restriction.getValue(), dataType);
		else if(restriction.getCondition().equals(">="))
			return isGreaterThanOrEqualTo(fieldValue, restriction.getValue(), dataType);	
		else if(restriction.getCondition().equals("<"))
			return isLessThan(fieldValue, restriction.getValue(), dataType);		
		else if(restriction.getCondition().equals("<="))
			return isLessThanOrEqualTo(fieldValue, restriction.getValue(), dataType);
		else
			return false;
		
	}
	
	private boolean isEqual(String s1, String s2, String dataType){
		if(dataType.equals("java.lang.Integer")) {
			return Integer.parseInt(s1)==Integer.parseInt(s2);
		} else if(dataType.equals("java.lang.Date")) {
			SimpleDateFormat date = new SimpleDateFormat("dd-MM-yyyy");
			try {
				if(date.parse(s1).compareTo(date.parse(s2)) == 0) 
					return true;
				else 
					return false;
			} catch (ParseException e) {
				e.printStackTrace();
			}
		} else if(dataType.equals("java.lang.Object")){
			return false;
		} else {
			if(s1.compareTo(s2) == 0){
				return true;
			} else {
				return false;
			}
		}
		return false;
	}
	
	private boolean isNotEqual(String s1, String s2, String dataType){
		return !(isEqual(s1,s2,dataType));
	}
	
	private boolean isGreaterThan(String s1, String s2, String dataType){
		if(dataType.equals("java.lang.Integer")) {
			return Integer.parseInt(s1) > Integer.parseInt(s2);
		} else if(dataType.equals("java.lang.Date")) {
			SimpleDateFormat date = new SimpleDateFormat("dd-MM-syyyy");
			try {
				if(date.parse(s1).compareTo(date.parse(s2)) > 0) 				
					return true;
					else 
					return false;
			} catch (ParseException e) {
				e.printStackTrace();
			}
		} else if(dataType.equals("java.lang.Object")){
			return false;
		} else {
			if(s1.compareTo(s2) > 0)
				return true;
			else 
				return false;
		}
		return false;
	}
	
	private boolean isGreaterThanOrEqualTo(String s1, String s2, String dataType){
		return isGreaterThan(s1,s2,dataType)|isEqual(s1,s2,dataType);
	}
	
	private boolean isLessThan(String s1, String s2, String dataType){
		return !(isGreaterThanOrEqualTo(s1,s2,dataType));
	}
	
	private boolean isLessThanOrEqualTo(String s1, String s2, String dataType){
		return isLessThan(s1,s2,dataType)|isEqual(s1,s2,dataType);
	}

}

