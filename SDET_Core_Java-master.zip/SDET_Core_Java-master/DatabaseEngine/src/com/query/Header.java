package com.query;

import java.util.HashMap;

public class Header extends HashMap<String,Integer> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
