package com.query;

import java.util.HashMap;

import com.csvread.CsvQueryProcessor;

public class Query {
	
	@SuppressWarnings("rawtypes")
	public HashMap executeQuery(String query){
		
		QueryParser queryParser = new QueryParser();
		
		QueryParameter queryParameter = queryParser.parseQuery(query);
		
		CsvQueryProcessor queryProcessor = new CsvQueryProcessor();
		

		try {
		return queryProcessor.getResultSet(queryParameter);
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
