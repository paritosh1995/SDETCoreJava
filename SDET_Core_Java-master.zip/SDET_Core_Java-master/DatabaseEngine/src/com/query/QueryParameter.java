package com.query;

import java.util.List;

public class QueryParameter {
	String fileName ;
	String baseQuery ;
	List<Restriction> restrictions ;
	List<String> fields ;
	String logicalOpt ;
	List<AggregateFunction> aggFunction ;
	List<String> orderByField ;
	List<String> groupByField ;
	
	public void setFileName(String fileName){
		this.fileName = fileName;
	}
	
	public String getFileName() {
		return fileName;
	}

	public String getBaseQuery() {
		return baseQuery;
	}

	public void setBaseQuery(String baseQuery) {
		this.baseQuery = baseQuery;
	}

	public List<Restriction> getRestrictions() {
		return restrictions;
	}

	public void setRestrictions(List<Restriction> restrictions) {
		this.restrictions = restrictions;
	}

	public List<String> getFields() {
		return fields;
	}

	public void setFields(List<String> fields) {
		this.fields = fields;
	}

	public String getLogicalOpt() {
		return logicalOpt;
	}

	public void setLogicalOpt(String logicalOpt) {
		this.logicalOpt = logicalOpt;
	}

	public List<AggregateFunction> getAggFunction() {
		return aggFunction;
	}

	public void setAggFunction(List<AggregateFunction> aggFunction) {
		this.aggFunction = aggFunction;
	}

	public List<String> getOrderByField() {
		return orderByField;
	}

	public void setOrderByField(List<String> orderByField) {
		this.orderByField = orderByField;
	}

	public List<String> getGroupByField() {
		return groupByField;
	}

	public void setGroupByField(List<String> groupByField) {
		this.groupByField = groupByField;
	}
	
}
