package com.query;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class QueryParser {
	
	private QueryParameter queryParameter = new QueryParameter();
	
	public QueryParameter parseQuery(String query) {
		queryParameter.setFileName(getFileName(query));
		queryParameter.setBaseQuery(getBaseQuery(query));
		queryParameter.setFields(getFields(query));
		queryParameter.setRestrictions(getRestriction(query));
		queryParameter.setLogicalOpt(getLogicalOpt(query));
		queryParameter.setOrderByField(getOrderByFields(query));
		queryParameter.setGroupByField(getOrderByFields(query));
		queryParameter.setAggFunction(getAggFunction(query));
		return queryParameter;
	}
	

	public String getFileName(String query){
		query = query.toLowerCase();
		String fileName = null;
		List<String> parsedQuery = Arrays.asList(query.split(" "));
		for(String s : parsedQuery){
			if(s.endsWith(".csv")){
				fileName = s;
			}		
		}
		return fileName;
	}
	
	public String getBaseQuery(String query){
		query = query.toLowerCase();
		List<String> baseSplit = Arrays.asList(query.split("where"));
		String baseQuery = baseSplit.get(0);
		return baseQuery;
	}
	
	public List<String> getFields(String query){
		query = query.toLowerCase();
		String multipleFields = query.substring(query.indexOf("select") + 7,query.indexOf("from")-1);
		List<String> fields = Arrays.asList(multipleFields.split(","));
		return fields;
	}
	
	public ArrayList<Restriction> getRestriction(String query) {
		if(query.contains("where") | query.contains("WHERE")) {
			String restFields = query.split("where|WHERE|group by|GROUP BY|order by|ORDER BY")[1].trim();
			String[] restrictList = restFields.split("and | or | AND |OR ");
			ArrayList<Restriction> restriction = new ArrayList<Restriction>();
			
			for(int i=0;i<restrictList.length;i++){
				if(restrictList[i].contains("'")){
					String condtName = restrictList[i].split(" ")[0];
					String[] restrictSplit = restrictList[i].split("'");
					Restriction r = new Restriction(condtName.trim(),restrictSplit[1].trim(),restrictSplit[0].trim().split(" ")[1]);
					restriction.add(r);
				}else {
					String[] restrictSplit = restrictList[i].split(" ");
					Restriction r = new Restriction(restrictSplit[0].trim(),restrictSplit[2].trim(),restrictSplit[1].trim());
					restriction.add(r);
				}
			}
			return restriction;
		} else {
			return null;
		}
	}
	
	public String getLogicalOpt(String query) {
		query = query.toLowerCase();
		if(query.contains("where")) {
			String restFileds = query.split("where|group by|order by")[1].trim();
			if(restFileds.contains(" and ")){
				return "and";
			}else if(restFileds.contains(" or ")) {
				return "or";
			}else {
				return "null";
			}
		}else {
			return null;
		}
	}
	
	public List<String> getOrderByFields(String query) {
		query = query.toLowerCase();
		if(query.contains("order by")) {
			String orderBy = null;
				if(query.contains("order by") && query.contains("group by") && query.contains("where")) {
					orderBy = query.split("where|group by|order by")[3].trim();
				} else if (query.contains("order by") && query.contains("group by")) {
					orderBy = query.split("group by|order by")[2].trim();
				} else if (query.contains("order by") && query.contains("where")) {
					orderBy = query.split("where|order by")[2].trim();
				} else if (query.contains("order by")) {
					orderBy = query.split("order by")[1].trim();
				} 
			List<String> orderByFields = Arrays.asList(orderBy.split(","));
			return orderByFields;
		} else {
			return null;
		}
	}
	
	public List<String> getGroupByFields(String query) {
		query = query.toLowerCase();
		if(query.contains("group by")) {
			String groupBy = null;
				if(query.contains("order by") && query.contains("group by") && query.contains("where")) {
					groupBy = query.split("where|group by|order by")[2].trim();
				} else if (query.contains("order by") && query.contains("group by")) {
					groupBy = query.split("group by|order by")[1].trim();
				} else if (query.contains("group by") && query.contains("where")) {
					groupBy = query.split("where|group by")[2].trim();
				} else if (query.contains("group by")) {
					groupBy = query.split("group by")[1].trim();
				} 
			List<String> groupByFields = Arrays.asList(groupBy.split(","));
			return groupByFields;
		} else {
			return null;
		}
	}
	
	public ArrayList<AggregateFunction> getAggFunction(String query) {
		query = query.toLowerCase();
		String selField= query.split("from")[0];
		if(selField.contains("(")) {
			String aggField = selField.split("select")[1].trim();
			String[] aggFn = aggField.split(",");
			ArrayList<AggregateFunction> aggreateFn = new ArrayList<AggregateFunction>();
			
			for(int i=0;i<aggFn.length;i++) {
				String[] aggFnSplit = aggFn[i].split("(|)");
				AggregateFunction a = new AggregateFunction(aggFnSplit[0],aggFnSplit[1]);
				aggreateFn.add(a);
			}
			
		return aggreateFn;
		} else {
			return null;
		}
	}
	
}
