package com.query;

import java.util.HashMap;

public class Row extends HashMap<String,String>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
