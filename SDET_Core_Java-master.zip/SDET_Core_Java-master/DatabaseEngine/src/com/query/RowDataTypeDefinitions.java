package com.query;

import java.util.HashMap;

public class RowDataTypeDefinitions extends HashMap<Integer,String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
