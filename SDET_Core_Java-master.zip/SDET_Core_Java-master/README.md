# SDET_Core_Java

This project contains SDET - Core Java Assignments.